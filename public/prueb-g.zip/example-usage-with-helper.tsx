import { getImagePath } from "@/lib/image-path"

// Uso del helper
;<Image src={getImagePath("Nico.jpeg") || "/placeholder.svg"} alt="Nico" width={200} height={200} />

