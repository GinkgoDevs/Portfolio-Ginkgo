/**
 * Helper para asegurar que las rutas de imágenes sean absolutas
 * @param path Ruta de la imagen
 * @returns Ruta absoluta de la imagen
 */
export function getImagePath(path: string): string {
  // Si la ruta ya es absoluta, devolverla tal cual
  if (path.startsWith("/")) {
    return path
  }

  // Si es una URL externa, devolverla tal cual
  if (path.startsWith("http://") || path.startsWith("https://")) {
    return path
  }

  // Convertir a ruta absoluta
  return `/${path}`
}

