import Image from "next/image"

// ❌ Incorrecto - Ruta relativa
;(<Image src="Nico.jpeg" alt="Nico" width={200} height={200} />) <
  // ✅ Correcto - Ruta absoluta\
  Image
src = "/Nico.jpeg"
alt = "Nico"
width={200}
height={200} />

