// Eliminar completamente este componente ya que está causando el error.
// Vamos a implementar una solución más simple y directa.

